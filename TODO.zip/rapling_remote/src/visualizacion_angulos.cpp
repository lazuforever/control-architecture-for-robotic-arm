// src/visualizacion_angulos.cpp

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include "gnuplot-iostream.h"
#include <iomanip>

using sensor_msgs::msg::JointState;

class VisualizacionAngulos : public rclcpp::Node
{
public:
  VisualizacionAngulos()
  : Node("visualizacion_angulos"),
    gp_("gnuplot -persist"),
    t0_(now().seconds()),
    final_received_(false)
  {
    RCLCPP_INFO(get_logger(), "Iniciando nodo de visualización de ángulos…");

    // Suscripciones
    serial_sub_ = create_subscription<JointState>(
      "/serial_joint_states", 10,
      std::bind(&VisualizacionAngulos::serialCallback, this, std::placeholders::_1)
    );
    final_sub_ = create_subscription<JointState>(
      "/final_angles", 10,
      std::bind(&VisualizacionAngulos::finalCallback, this, std::placeholders::_1)
    );

    // Configuración inicial de la ventana GNUplot
    gp_ << "set title 'Serial vs Final Angles'\n"
           "set xlabel 'Tiempo (s)'\n"
           "set ylabel 'Ángulo (rad)'\n"
           "set grid\n";

    RCLCPP_INFO(get_logger(), "Nodo listo: esperando mensajes...");
  }

private:
  void finalCallback(const JointState::SharedPtr msg)
  {
    // Log por consola
    std::ostringstream oss;
    oss << "[FINAL] posiciones = [ ";
    for (double v : msg->position) oss << std::fixed << std::setprecision(3) << v << " ";
    oss << "]";
    RCLCPP_INFO(get_logger(), oss.str().c_str());

    if (final_received_) {
      // Ya teníamos el objetivo; no lo re-procesamos
      return;
    }

    // Primera llegada: guardamos objetivos
    final_received_ = true;
    final_targets_ = msg->position;              // tamaño 4
    size_t N = final_targets_.size();

    // Preparamos final_series_ para mantener valores constantes
    final_series_.assign(N, std::vector<double>());

    // Si ya tenemos timestamps previos, rellénalos
    for (size_t i = 0; i < N; ++i) {
      final_series_[i].resize(ts_.size(), final_targets_[i]);
    }

    RCLCPP_INFO(get_logger(), "Ángulos objetivo almacenados (%zu joints).", N);
  }

  void serialCallback(const JointState::SharedPtr msg)
  {
    // Log por consola
    std::ostringstream oss;
    oss << "[SERIAL] posiciones = [ ";
    for (double v : msg->position) oss << std::fixed << std::setprecision(3) << v << " ";
    oss << "]";
    RCLCPP_INFO(get_logger(), oss.str().c_str());

    // Tiempo relativo
    double t = now().seconds() - t0_;
    ts_.push_back(t);

    // Primera llegada: inicializamos series
    if (serial_series_.empty()) {
      size_t N = msg->position.size();
      serial_series_.assign(N, std::vector<double>());

      // Si ya tenemos objetivos, sincronizamos final_series_
      if (final_received_) {
        for (size_t i = 0; i < N; ++i) {
          final_series_[i].push_back(final_targets_[i]);
        }
      }
    }

    // Añadimos el nuevo valor serial
    for (size_t i = 0; i < msg->position.size(); ++i) {
      serial_series_[i].push_back(msg->position[i]);
      // Si ya tenemos objetivo, mantenemos su valor constante
      if (final_received_) {
        final_series_[i].push_back(final_targets_[i]);
      }
    }

    // Redibujamos
    plotAll();
  }

  void plotAll()
  {
    if (!final_received_) {
      // Aún no llegó /final_angles
      return;
    }

    size_t N = final_targets_.size();

    // Construyo el comando de plot: 2*N series
    gp_ << "plot ";
    for (size_t i = 0; i < N; ++i) {
      // serie serial[i]
      gp_ << "'-' with lines lw 2 title 'serial["<<i<<"]', ";
      // serie final[i] punteada
      gp_ << "'-' with lines dt 2 title 'final["<<i<<"]'";
      if (i+1 < N) gp_ << ", ";
    }
    gp_ << "\n";

    // Envío datos serial
    for (size_t i = 0; i < N; ++i) {
      gp_.send1d(boost::make_tuple(ts_, serial_series_[i]));
    }
    // Envío datos final (constantes)
    for (size_t i = 0; i < N; ++i) {
      gp_.send1d(boost::make_tuple(ts_, final_series_[i]));
    }

    // Refresco rápido
    gp_ << "pause 0.01\n";
  }

  // Miembros
  Gnuplot gp_;
  double t0_;
  bool final_received_;

  std::vector<double> ts_;
  std::vector<std::vector<double>> serial_series_;
  std::vector<double> final_targets_;
  std::vector<std::vector<double>> final_series_;

  rclcpp::Subscription<JointState>::SharedPtr serial_sub_;
  rclcpp::Subscription<JointState>::SharedPtr final_sub_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<VisualizacionAngulos>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
